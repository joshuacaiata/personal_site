#ifndef __CARD_H__
#define __CARD_H__
#include <string>

using namespace std;

class Card {
public:
	string suit;
	string rank;
	int value;
	Card(string suit, string rank, int value);
	void displayCard();
	bool operator==(Card card);
};

#endif