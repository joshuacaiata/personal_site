#ifndef __BOARD_H__
#define __BOARD_H__
#include <vector>
#include <string>

using namespace std;

class Card;
class Player;

class Board {
public:
	vector<Card> spades;
	vector<Card> diamonds;
	vector<Card> clubs;
	vector<Card> hearts;
	vector<Player> players;
	Board();
	Board(vector<Card> spades, vector<Card> diamonds, vector<Card> clubs, vector<Card> hearts, vector<Player> players);
	void displayBoard();
	bool checkWinner();
	bool endRound();
	vector<int> findWinningPlayer();
	int findStartingPlayer();
};

#endif
