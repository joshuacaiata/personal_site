#include <iostream>
#include "board.h"
#include "card.h"
#include "player.h"

Board::Board() {}

Board::Board(vector<Card> spades, vector<Card> diamonds, vector<Card> clubs, vector<Card> hearts, vector<Player> players) : spades{spades}, diamonds{diamonds}, clubs{clubs}, hearts{hearts}, players{players} {}

void Board::displayBoard() {
	cout << "Cards on the table:" << endl;
	cout << "Clubs: ";
	for (int i = 0; i < clubs.size(); i++) {
		clubs[i].displayCard();
	}
	cout << endl;
	
	cout << "Diamonds: ";
	for (int i = 0; i < diamonds.size(); i++) {
		diamonds[i].displayCard();
	}
	cout << endl;
	
	cout << "Hearts: ";
	for (int i = 0; i < hearts.size(); i++) {
		hearts[i].displayCard();
	}
	cout << endl;
	
	cout << "Spades: ";
	for (int i = 0; i < spades.size(); i++) {
		spades[i].displayCard();
	}
	cout << endl;
}

bool Board::checkWinner() {
	for (int i = 0; i < players.size(); i++) {
		int score = players[i].score;
		if (score >= 80) {
			return true;
		}
	}
	return false;
}

bool Board::endRound() {
	bool end = true;
	for (int i = 0; i < players.size(); i++) {
		if (players[i].hand.size() > 0) {
			end = false;
		}
	}
	return end;
}

vector<int> Board::findWinningPlayer() {
	vector<int> winners;
	int min = players[0].score;
	for (int i = 0; i < players.size(); i++) {
		if (players[i].score < min) {
			min = players[i].score;
		}
	}
	
	for (int i = 0; i < players.size(); i++) {
		if (players[i].score == min) {
			winners.emplace_back(i + 1);
		}
	}
	
	return winners;
}

int Board::findStartingPlayer() {
	Card sspade = Card("S", "7", 7);
	int starter = 0;
	for (int i = 0; i < players.size(); i++) {
		for (int j = 0; j < players[i].hand.size(); j++) {
			bool test = (sspade == players[i].hand[j]);
			if (sspade == players[i].hand[j]) {
				starter = i + 1;
			}
		}
	}
	return starter;
}