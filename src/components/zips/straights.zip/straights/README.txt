Hello!

If you made it this far, thank you! Feel free to look around the code. It's all in C++, built all on my own using OOP principles. I also included my UML diagram so you can orient yourself.

The rules of the game are simple:
Player with the 7 of spades starts the game, and then each player that follows plays a card of adjacent rank and same suit of cards that are already on the board, or they can play a 7 of any suit to get the suit started. If the player has a legal play, they must play a card, otherwise they must discard. To play a card, type in "play" followed by the card (for example, 7 of spades is 7S). To discard a card, type in "discard" followed by the card you wish to discard. 

Once all the cards are played or discarded, the discarded cards are summed up and a new round begins. The game continues until a player has more than 60 points. When this occurs, the player with the lowest score wins!

Commands:
play {number}{suit}
discard {number}{suit}
ragequit

Ragequit removes that player from the game and replaces it with a computer player.

Run make to compile the program. Have fun!