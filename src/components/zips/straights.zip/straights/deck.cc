#include "deck.h"
#include <algorithm>
#include <iostream>
#include <random>

using namespace std;

Deck::Deck(vector<Card> deck) : deck{deck} {}

void Deck::displayDeck() {
	int j = 1;
	for (int i = 0; i < deck.size(); i++) {
		cout << deck[i].rank << deck[i].suit;
		if (j != 13) {
			cout << " ";
		}
		j++;
		if (j == 14) {
			cout << endl;
			j = 1;
		}
	}
}

void Deck::shuffleDeck(int seed) { 
	shuffle( deck.begin(), deck.end(), default_random_engine(seed));
}

void Deck::deal(vector<Player>& players) {
	for (int i = 0; i < 13; i++) {
		players[0].hand.emplace_back(deck[i]);
	}
	
	for (int i = 13; i < 26; i++) {
		players[1].hand.emplace_back(deck[i]);
	}
	
	for (int i = 26; i < 39; i++) {
		players[2].hand.emplace_back(deck[i]);
	}
	
	for (int i = 39; i < 52; i++) {
		players[3].hand.emplace_back(deck[i]);
	}
}
