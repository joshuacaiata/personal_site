#include "card.h"
#include "iostream"

using namespace std;

Card::Card(string suit, string rank, int value) : suit{suit}, rank{rank}, value{value} {}

void Card::displayCard() {
	cout << " " << this->rank << this->suit;
}

bool Card::operator==(Card card) {
	if (suit == card.suit && rank == card.rank && value == card.value) {
		return true;
	} else {
		return false;
	}
}
