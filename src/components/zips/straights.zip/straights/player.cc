#include "player.h"
#include "card.h"
#include <iostream>
#include <sstream>

Player::Player() { score = 0; }

Player::Player(vector<Card> hand, vector<Card> discarded, int score, bool human) : hand{hand}, discarded{discarded}, score{score}, human{human} {}

bool Player::discard(Board& board, string my_card, int current_player) {
	// Check if player has card
	char rank = toupper(my_card[0]);
	char suit = toupper(my_card[1]);
	Card card = getCard(rank, suit);
	if (card.value == -1) { return false; }
	vector<Card> legals = getLegal(board);
	if (legals.size() > 0) { return false; }
	for (int i = 0; i < hand.size(); i++) {
		if (hand[i].rank == card.rank && hand[i].suit == card.suit) {
			Card to_move = hand[i];
			discarded.emplace_back(to_move);
			hand.erase(hand.begin() + i);
		}
	}
	
	cout << "Player" << current_player << " discards";
	card.displayCard();
	cout << endl;
	
	return true;
}

void Player::displayHand() {
	for (int i = 0; i < hand.size(); i++) {
		hand[i].displayCard();
	}
	cout << endl;
}

void Player::displayDiscards() {
	for (int i = 0; i < discarded.size(); i++) {
		discarded[i].displayCard();
	}
	cout << endl;
}

bool Player::checkMove(Board board, Card card) {
	
	if (board.spades.size() == 0 && board.diamonds.size() == 0 && board.hearts.size() == 0 && board.clubs.size() == 0) {
		if (card.suit == "S" && card.value == 7) {
			return true;
		} else {
			return false;
		}
	}
	
	if (card.suit == "S") {
		if (board.spades.size() == 0) {
			if (card.value == 7) {
				return true;
			} else {
				return false;
			}
		} else {
			if (board.spades[0].value == 1 && board.spades[board.spades.size() - 1].value == 13) {
				return false;
			} else if ((board.spades[0].value - 1 == card.value) || (board.spades[board.spades.size() - 1].value + 1 == card.value)) {
				return true;
			} else {
				return false;
			}
		}
	} else if (card.suit == "D") {
		if (board.diamonds.size() == 0) {
			if (card.value == 7) {
				return true;
			} else {
				return false;
			}
		} else {
			if (board.diamonds[0].value == 1 && board.diamonds[board.diamonds.size() - 1].value == 13) {
				return false;
			} else if ((board.diamonds[0].value - 1 == card.value) || (board.diamonds[board.diamonds.size() - 1].value + 1 == card.value)) {
				return true;
			} else {
				return false;
			}
		}
	} else if (card.suit == "H") {
		if (board.hearts.size() == 0) {
			if (card.value == 7) {
				return true;
			} else {
				return false;
			}
		} else {
			if (board.hearts[0].value == 1 && board.hearts[board.hearts.size() - 1].value == 13) {
				return false;
			} else if ((board.hearts[0].value - 1 == card.value) || (board.hearts[board.hearts.size() - 1].value + 1 == card.value)) {
				return true;
			} else {
				return false;
			}
		}
	} else {
		if (board.clubs.size() == 0) {
			if (card.value == 7) {
				return true;
			} else {
				return false;
			}
		} else {
			if (board.clubs[0].value == 1 && board.clubs[board.clubs.size() - 1].value == 13) {
				return false;
			} else if ((board.clubs[0].value - 1 == card.value) || (board.clubs[board.clubs.size() - 1].value + 1 == card.value)) {
				return true;
			} else {
				return false;
			}
		}
	}
}

vector<Card> Player::getLegal(Board board) {
	vector<Card> legals;
	int handSize = hand.size();
	//cout << "Hand size: " << handSize << endl;
	for (int i = 0; i < handSize; i++) {
		//cout << "i: " << i << endl;
		if (checkMove(board, hand[i])) {
			legals.emplace_back(hand[i]);
		}
	}
	return legals;
}

void Player::displayLegal(Board board) {
	vector<Card> legals = getLegal(board);
	if (legals.size() > 0) {
		for (int i = 0; i < legals.size() - 1; i++) {
			legals[i].displayCard();
		}
		
		cout << " " << legals[legals.size() - 1].rank << legals[legals.size() - 1].suit << endl;
	} else {
		cout << endl;
	}
}

int Player::getScore() {
	int score = 0;
	
	for (int i = 0; i < discarded.size(); i++) {
		score += discarded[i].value;
	}
	
	return score;
}

void Player::play(Board& board, int current_player) {
	vector<Card> legals = getLegal(board);
	if (legals.size() == 0) {
		string my_card = hand[0].rank + hand[0].suit;
		discard(board, my_card, current_player);
	} else {
		Card card = legals[0];
		if (card.suit == "S") {
			if (board.spades.size() == 0) {
				board.spades.emplace_back(card);
			} else if (card.value + 1 == board.spades[0].value) {
				int size = board.spades.size();
				board.spades.insert(board.spades.begin(), card);
			} else {
				board.spades.emplace_back(card);
			}
		} else if (card.suit == "D") {
			if (board.diamonds.size() == 0) {
				board.diamonds.emplace_back(card);
			} else if (card.value + 1 == board.diamonds[0].value) {
				int size = board.diamonds.size();
				board.diamonds.insert(board.diamonds.begin(), card);
			} else {
				board.diamonds.emplace_back(card);
			}
		} else if (card.suit == "H") {
			if (board.hearts.size() == 0) {
				board.hearts.emplace_back(card);
			} else if (card.value + 1 == board.hearts[0].value) {
				int size = board.hearts.size();
				board.hearts.insert(board.hearts.begin(), card);
			} else {
				board.hearts.emplace_back(card);
			}
		} else {
			if (board.clubs.size() == 0) {
				board.clubs.emplace_back(card);
			} else if (card.value + 1 == board.clubs[0].value) {
				int size = board.clubs.size();
				board.clubs.insert(board.clubs.begin(), card);
			} else {
				board.clubs.emplace_back(card);
			}
		}
		
		for (int i = 0; i < hand.size(); i++) {
			if (hand[i] == card) {
				hand.erase(hand.begin() + i);
			}
		}
		
		cout << "Player" << current_player << " plays";
		card.displayCard();
		cout << endl;
		
	}
	
}

Card Player::getCard(char rank, char suit) {
	for (int i = 0; i < hand.size(); i++) {
		if (hand[i].rank[0] == rank && hand[i].suit[0] == suit) {
			return hand[i];
		}
	}
	
	// Return Error card if player does not have the card
	return Card("E", "E", -1);
}

bool Player::play(Board& board, string my_card, int current_player) {
	// Check if player has card
	char rank = toupper(my_card[0]);
	char suit = toupper(my_card[1]);
	Card card = getCard(rank, suit);
	if (card.value == -1) { return false; }
	
	if (checkMove(board, card) == false) {
		return false;
	} else {
		if (card.suit == "S") {
			if (board.spades.size() == 0) {
				board.spades.emplace_back(card);
			} else if (card.value + 1 == board.spades[0].value) {
				int size = board.spades.size();
				board.spades.insert(board.spades.begin(), card);
			} else {
				board.spades.emplace_back(card);
			}
		} else if (card.suit == "D") {
			if (board.diamonds.size() == 0 ) {
				board.diamonds.emplace_back(card);
			} else if (card.value + 1 == board.diamonds[0].value) {
				int size = board.diamonds.size();
				board.diamonds.insert(board.diamonds.begin(), card);
			} else {
				board.diamonds.emplace_back(card);
			}
		} else if (card.suit == "H") {
			if (board.hearts.size() == 0) {
				board.hearts.emplace_back(card);
			} else if (card.value + 1 == board.hearts[0].value) {
				int size = board.hearts.size();
				board.hearts.insert(board.hearts.begin(), card);
			} else {
				board.hearts.emplace_back(card);
			}
		} else {
			if (board.clubs.size() == 0) {
				board.clubs.emplace_back(card);
			} else if (card.value + 1 == board.clubs[0].value) {
				int size = board.clubs.size();
				board.clubs.insert(board.clubs.begin(), card);
			} else {
				board.clubs.emplace_back(card);
			}
		}
	}
	
	for (int i = 0; i < hand.size(); i++) {
		if (hand[i] == card) {
			hand.erase(hand.begin() + i);
		}
	}
	
	cout << "Player" << current_player << " plays";
	card.displayCard();
	cout << endl;
	
	return true;
}

void Player::ragequit() {
	human = false;
}