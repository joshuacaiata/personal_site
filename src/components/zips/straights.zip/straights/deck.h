#ifndef __DECK_H__
#define __DECK_H__
#include <vector>
#include "card.h"
#include "player.h"

using namespace std;

class Deck {
	
public:
	vector<Card> deck;
	Deck(vector<Card> deck);
	void displayDeck();
	void shuffleDeck(int seed);
	void deal(vector<Player>& players);
};

#endif