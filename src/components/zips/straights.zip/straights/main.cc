#include <iostream>
#include <algorithm>
#include <vector>
#include "board.h"
#include "card.h"
#include "deck.h"
#include "player.h"

using namespace std;
int main(int argc, char *argv[]) {
	
	vector<Card> all = {
		Card("C", "A", 1),
		Card("C", "2", 2),
		Card("C", "3", 3),
		Card("C", "4", 4),
		Card("C", "5", 5),
		Card("C", "6", 6),
		Card("C", "7", 7),
		Card("C", "8", 8),
		Card("C", "9", 9),
		Card("C", "T", 10),
		Card("C", "J", 11),
		Card("C", "Q", 12),
		Card("C", "K", 13),
		Card("D", "A", 1),
		Card("D", "2", 2),
		Card("D", "3", 3),
		Card("D", "4", 4),
		Card("D", "5", 5),
		Card("D", "6", 6),
		Card("D", "7", 7),
		Card("D", "8", 8),
		Card("D", "9", 9),
		Card("D", "T", 10),
		Card("D", "J", 11),
		Card("D", "Q", 12),
		Card("D", "K", 13),
		Card("H", "A", 1),
		Card("H", "2", 2),
		Card("H", "3", 3),
		Card("H", "4", 4),
		Card("H", "5", 5),
		Card("H", "6", 6),
		Card("H", "7", 7),
		Card("H", "8", 8),
		Card("H", "9", 9),
		Card("H", "T", 10),
		Card("H", "J", 11),
		Card("H", "Q", 12),
		Card("H", "K", 13),
		Card("S", "A", 1),
		Card("S", "2", 2),
		Card("S", "3", 3),
		Card("S", "4", 4),
		Card("S", "5", 5),
		Card("S", "6", 6),
		Card("S", "7", 7),
		Card("S", "8", 8),
		Card("S", "9", 9),
		Card("S", "T", 10),
		Card("S", "J", 11),
		Card("S", "Q", 12),
		Card("S", "K", 13),
	};
	
	int seed = 44;
	if (argc >= 2) {
		seed = stoi(argv[1]);
	}
	
	Deck deck = Deck(all);
	deck.shuffleDeck(seed);
	Board main = Board();
	
	int player_count = 1;
	
	while (player_count <= 4) {
		cout << "Is Player" << player_count << " a human (h) or a computer (c)?" << endl;
		
		string type;
		cin >> type;
		
		if (type == "h") {
			Player player = Player();
			player.human = true;
			main.players.emplace_back(player);
			player_count++;
		} else if (type == "c") {
			Player player = Player();
			player.human = false;
			main.players.emplace_back(player);
			player_count++;
		} else if (type == "quit") {
			exit(EXIT_SUCCESS);
		} else {
			cout << "Invalid input, try again." << endl;
		}
	}
	
	deck.deal(main.players);
	
	int current_player = main.findStartingPlayer();
	bool player_turn = true;
	string command;
	cout << "A new round begins. It's Player" << current_player << "'s turn to play." << endl;
	while(!main.checkWinner()) {
		player_turn = true;
		
		main.displayBoard();
		cout << "Your hand:";
		main.players[current_player-1].displayHand();
		cout << "Legal plays:";
		main.players[current_player-1].displayLegal(main);
		
		
		while(player_turn) {
			if (main.players[current_player-1].human) {
				if (main.players[current_player - 1].hand.size() == 0) {
					player_turn = false;
					continue;
				}
				
				cin >> command;
				
				if (command == "play") {
					string player_card;
					cin >> player_card;
					if (!main.players[current_player-1].play(main, player_card, current_player)) {
						cout << "This is not a legal play." << endl;
						player_turn = true;
						continue;
					}
					player_turn = false;
				} else if (command == "discard") {
					string player_card;
					cin >> player_card;
					if (!main.players[current_player-1].discard(main, player_card, current_player)) {
						cout << "You have a legal play. You may not discard." << endl;
						player_turn = true;
						continue;
					}
					player_turn = false;
				} else if (command == "deck") {
					deck.displayDeck();
					player_turn = true;
				} else if (command == "ragequit") {
					cout << "Player" << current_player << " ragequits. A computer will now take over." << endl;
					main.players[current_player-1].ragequit();
					main.players[current_player-1].play(main, current_player);
					player_turn = false;
				} else if (command == "quit") {
					player_turn = false;
					exit(EXIT_SUCCESS);
				} else {
					cout << "Invalid input, try again." << endl;
					player_turn = true;
				}
			} else {
				main.players[current_player-1].play(main, current_player);
				player_turn = false;
			}
		}
		
		if (main.endRound()) {
			for (int i = 0; i < main.players.size(); i++) {
				cout << "Player" << i+1 << "'s discards:";
				main.players[i].displayDiscards();
				cout << "Player" << i+1 << "'s score:" << main.players[i].score << " + " << main.players[i].getScore() << " = " << main.players[i].score + main.players[i].getScore() << endl;
				main.players[i].score += main.players[i].getScore();
			}
			
			if (main.checkWinner()) {
				vector<int> winners = main.findWinningPlayer();
				
				for (int i = 0; i < winners.size(); i++) {
					cout << "Player" << winners[i] << " wins!" << endl;
				}
				
				break;
			} else {
				for (int i = 0; i < main.players.size(); i++) {
					main.players[i].discarded.clear();
					main.players[i].hand.clear();
				}
				main.spades.clear();
				main.diamonds.clear();
				main.hearts.clear();
				main.clubs.clear();
				deck.shuffleDeck(seed);
				deck.deal(main.players);
				current_player = main.findStartingPlayer();
				cout << "A new round begins. It's Player" << current_player << "'s turn to play." << endl;
			}
			
		} else {
			if (current_player == 4) {
				current_player = 1;
			} else {
				current_player++;
			}
		}
		
	}
}