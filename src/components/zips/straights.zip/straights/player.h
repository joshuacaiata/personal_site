#ifndef __PLAYER_H__
#define __PLAYER_H__
#include <vector>
#include "board.h"

using namespace std;

class Card;

class Player {
public:
	vector<Card> hand;
	vector<Card> discarded;
	int score;
	bool human;
	Player();
	Player(vector<Card> hand, vector<Card> discarded, int score, bool human);
	bool discard(Board& board, string my_card, int current_player);
	void displayHand();
	void displayDiscards();
	bool checkMove(Board board, Card card);
	void displayLegal(Board board);
	vector<Card> getLegal(Board board);
	void play(Board& board, int current_player);
	bool play(Board& board, string my_card, int current_player);
	int getScore();
	Card getCard(char rank, char suit);
	void ragequit();
};

#endif