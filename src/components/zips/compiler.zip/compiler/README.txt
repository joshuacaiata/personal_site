Hello! This is my compiler.

This was built over the course of CS241. I will admit parts of the code don't make sense, this is likely because of the way it was
pieced together by instructors (the way they expected input/output formats, etc.) 

It isn't possible for me to give a proper code-to-binary demo in this ZIP file since it does require some software that is only available
on the uWaterloo student server, however, feel free to look around.

This was all programmed on my own, in Racket (which is a language similar to LISP).